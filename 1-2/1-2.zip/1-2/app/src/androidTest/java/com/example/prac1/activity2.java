package com.example.prac1;

public class activity2 {

}
val btn:button = findViewById(R.id.btn_1)
        btn.setonClickListener{
    val intent= (package this,MainActivity2::class.java)
    startActivity(intent)
}